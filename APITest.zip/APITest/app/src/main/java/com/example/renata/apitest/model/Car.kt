package com.example.renata.apitest.model

class Car (val reservation: String,
           val plate: String,
           val time: String,
           var paid: Boolean,
           val left: Boolean
)