package com.example.renata.apitest.model

class History(val time:String,val pago :String, val plate: String) {
}