package com.example.renata.apitest.model

import java.util.*

class Entrance (val reservation: String,
                val plate: String,
                val entered_at: Date
)