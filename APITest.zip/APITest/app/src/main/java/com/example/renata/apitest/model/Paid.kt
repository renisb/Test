package com.example.renata.apitest.model

class Paid(val number:Int)