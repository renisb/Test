package com.example.renata.apitest.model

import java.util.*

class Plate (val plate: String)